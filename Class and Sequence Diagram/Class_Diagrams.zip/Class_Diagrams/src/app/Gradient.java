package app;
import grading.*;
import java.util.*;

public class Gradient {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
