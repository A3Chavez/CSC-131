package grading;
import java.util.*;

public interface Filter {
	public List<Grade> apply(java.util.List<Grade> grades) throws SizeException {
		
	}
}
