package grading;
import java.util.*;

public interface GradingStrategy {
	public Grade calculate(String key, java.util.List<Grade> grades) throws SizeException {
		
	}
}
