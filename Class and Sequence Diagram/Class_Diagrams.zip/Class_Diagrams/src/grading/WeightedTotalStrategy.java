package grading;
import java.util.*;
import grading.Missing;

public class WeightedTotalStrategy implements GradingStrategy {
	private java.util.Map<java.lang.String, java.lang.Double> weights;
	
	public WeightedTotalStrategy() {
		
	}
	
	public WeightedTotalStrategy(Map<java.lang.String, java.lang.Double> weights) {
		
	}
	
	public Grade calculate(String key, java.util.List<Grade> grades) throws SizeException {
		return null;
	}
}
