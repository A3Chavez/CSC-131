package grading;

public final class Missing {
	private static double DEFAULT_MISSING_VALUE = 0.0;
	
	public static double doubleValue(Double number) {
		
	}
	
	public static double doubleValue(Double number, double missingValue) {
		
	}
}