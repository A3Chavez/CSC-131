package grading;

public class TotalStrategy extends WeightedTotalStrategy {
	public TotalStrategy() {
		
	}
}
